# CompIntelAss1
